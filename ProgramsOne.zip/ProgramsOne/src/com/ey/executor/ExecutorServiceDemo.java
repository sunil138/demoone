package com.ey.executor;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

class Task implements Runnable
{

	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName());
	}
	
}
public class ExecutorServiceDemo {

	public static void main(String[] args) {

		Executor e=Executors.newSingleThreadExecutor();
		Runnable r=()-> System.out.println(Thread.currentThread().getName());
		for(int i=0;i<5;i++)
		{
			e.execute(r); 
		}
	
	}

}
