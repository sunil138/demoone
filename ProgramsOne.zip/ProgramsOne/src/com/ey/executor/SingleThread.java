package com.ey.executor;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

class TaskTwo implements Runnable
{

	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName()); 
	}
	
}
public class SingleThread {

	public static void main(String[] args) {
		Executor e=Executors.newSingleThreadExecutor();
		for(int i=0;i<5;i++)
		{
		e.execute(new Task());
		}
	}

}

