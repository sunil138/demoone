package com.ey.executor;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

class TaskOne implements Runnable 
{

	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName());
	}
	
}
public class FixedThread {

	public static void main(String[] args) {
		Executor e=Executors.newFixedThreadPool(3); 
		for(int i=0;i<5;i++) 
		{
		e.execute(new Task());
		}
	}

}


