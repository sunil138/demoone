package com.ey.executor;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
class TaskThree implements Callable<Integer>
{

	@Override
	public Integer call() throws Exception {
		
		return 1;
	}

}

public class ExecutorServiceOne {

	public static void main(String[] args) {
		
		ExecutorService e=Executors.newFixedThreadPool(3);
		Future<Integer> future=e.submit(new TaskThree());
		try
		{
			System.out.println(future.get());
		}catch(InterruptedException e1) {
			e1.printStackTrace();
		}catch(ExecutionException e1) {
			e1.printStackTrace();
		}
	}

}
